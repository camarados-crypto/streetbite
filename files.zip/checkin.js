let ciRating = 0, ciPhotoFile = null, ciPhotoDataUrl = null;

// ── OPEN / CLOSE ──────────────────────────────────────
function openCheckin() {
  if (!activeDish) return;
  $('ci-dish-name').textContent = activeDish.name;
  $('ci-dish-coll').textContent = activeColl?.name || '';
  if (activeDish.image_url) { $('ci-dish-img').innerHTML = `<img src="${activeDish.image_url}" alt="${activeDish.name}">`; }
  else { $('ci-dish-img').innerHTML = `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:24px;background:#F0EBE4">🍽️</div>`; }
  ciRating = 0; ciPhotoFile = null; ciPhotoDataUrl = null;
  $('ci-price').value = ''; $('ci-location').value = ''; $('ci-note').value = '';
  $('ci-photo-preview').style.display = 'none'; $('ci-photo-preview').src = '';
  $('ci-photo-area').querySelector('.ci-photo-icon').style.display = 'block';
  $('ci-photo-area').querySelector('.ci-photo-txt').style.display  = 'block';
  $('ci-uploading').style.display = 'none'; $('ci-save').disabled = false;
  updateStars(0);
  $('ci-currency').value = COUNTRY_CURRENCY[currentCountry?.name] || 'USD';
  $('ci-backdrop').classList.add('open');
}
function closeCheckin()          { $('ci-backdrop').classList.remove('open'); }
function ciBackdropClick(e)      { if (e.target === $('ci-backdrop')) closeCheckin(); }
function setRating(n)            { ciRating = n; updateStars(n); }
function updateStars(n)          { $('ci-stars').querySelectorAll('.ci-star').forEach((s,i) => s.classList.toggle('on', i < n)); }

// ── PHOTO SELECT ──────────────────────────────────────
function handlePhotoSelect(e) {
  const file = e.target.files[0]; if (!file) return;
  ciPhotoFile = file;
  const reader = new FileReader();
  reader.onload = ev => {
    ciPhotoDataUrl = ev.target.result;
    $('ci-photo-preview').src = ciPhotoDataUrl; $('ci-photo-preview').style.display = 'block';
    $('ci-photo-area').querySelector('.ci-photo-icon').style.display = 'none';
    $('ci-photo-area').querySelector('.ci-photo-txt').style.display  = 'none';
  };
  reader.readAsDataURL(file);
}

// ── GPS ───────────────────────────────────────────────
function useGPS() {
  if (!navigator.geolocation) { alert('Location not available'); return; }
  navigator.geolocation.getCurrentPosition(async pos => {
    const { latitude, longitude } = pos.coords;
    try {
      const r = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`);
      const d = await r.json();
      $('ci-location').value = d.address?.road || d.address?.suburb || d.display_name?.split(',')[0] || `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
    } catch(e) { $('ci-location').value = `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`; }
  }, () => alert('Could not get location'));
}

// ── PHOTO UPLOAD ──────────────────────────────────────
async function uploadPhoto() {
  if (!ciPhotoFile || !sbClient) return null;
  const ext  = ciPhotoFile.name.split('.').pop() || 'jpg';
  const path = `${uid}/${activeDish.id}_${Date.now()}.${ext}`;
  const { data, error } = await sbClient.storage.from('checkin-photos').upload(path, ciPhotoFile, { upsert:true, contentType:ciPhotoFile.type });
  if (error) { console.error('Photo upload:', error); return null; }
  const { data: urlData } = sbClient.storage.from('checkin-photos').getPublicUrl(path);
  return urlData?.publicUrl || null;
}

// ── SAVE CHECK-IN ─────────────────────────────────────
async function saveCheckin() {
  if (!activeDish) return;
  $('ci-save').disabled = true;
  let photoUrl = null;
  if (ciPhotoFile) { $('ci-uploading').style.display = 'flex'; photoUrl = await uploadPhoto(); $('ci-uploading').style.display = 'none'; }
  const exp = {
    dish_id:  activeDish.id, user_id: uid,
    rating:   ciRating || null,
    location_text: $('ci-location').value.trim() || null,
    note:     $('ci-note').value.trim() || null,
    price:    parseFloat($('ci-price').value) || null,
    currency: $('ci-currency').value || 'USD',
    photo_url: photoUrl,
    user_display_name: sbUser?.user_metadata?.full_name || sbUser?.user_metadata?.name || null,
    user_avatar_url:   sbUser?.user_metadata?.avatar_url || null,
  };
  try {
    const result = await api('experiences', { method:'POST', headers:{'Prefer':'return=representation'}, body:JSON.stringify(exp) });
    const expId  = Array.isArray(result) ? result[0]?.id : result?.id;
    await markCollected(activeDish.id, expId);
  } catch(e) { await markCollected(activeDish.id, null); }
  closeCheckin(); showCollectedFeedback();
}
async function skipCheckin() { closeCheckin(); await markCollected(activeDish.id, null); showCollectedFeedback(); }

// ── MARK COLLECTED ────────────────────────────────────
async function markCollected(dishId, expId) {
  const alreadyInSet = userDishes.has(dishId);
  if (!alreadyInSet) {
    userDishes.add(dishId); saveLocal();
    try {
      const body = { user_id:uid, dish_id:dishId };
      if (expId) body.experience_id = expId;
      await api('user_dishes', { method:'POST', headers:{'Prefer':'resolution=merge-duplicates,return=minimal'}, body:JSON.stringify(body) });
    } catch(e) { console.log('markCollected:', e.message); }
  }
  if (activeColl) { const col = collections.find(c => c.id === activeColl.id); if (col) col.collected = col.dishes.filter(d => userDishes.has(d.id)).length; }
  if (!$('s-coll').classList.contains('gone') && activeColl) renderColl(activeColl);
  if (!$('s-home').classList.contains('gone')) {
    renderHome();
    setTimeout(initScrollReveal, 50);
    const firstBites = allDishes.filter(d => d.first_bite_order != null);
    const fbDone     = firstBites.filter(d => userDishes.has(d.id)).length;
    if (fbDone === 3 && firstBites.length >= 3) setTimeout(showUnlockMoment, 600);
  }
}

// ── FEEDBACK TOAST ────────────────────────────────────
function showCollectedFeedback() {
  updateCollectBtn(true); updateCardStatus(true);
  const toast = document.createElement('div');
  toast.style.cssText = `position:fixed;top:80px;left:50%;transform:translateX(-50%);background:#1C1208;color:#fff;padding:10px 20px;border-radius:30px;font-size:13px;font-weight:600;z-index:300;animation:fadeInOut 2s ease forwards;font-family:'DM Sans',sans-serif;box-shadow:0 4px 20px rgba(0,0,0,.3);white-space:nowrap`;
  toast.textContent = `✓ ${activeDish?.name} checked!`;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 2200);
}
